# Fluxo do sistema

```
 ┌─────────────────────────┐
 │   index.html             │   Front-end (GitHub Pages, gratuito)
 │   (preenchimento ficha)  │
 └────────────┬─────────────┘
              │
      ┌───────┼────────────────────┐
      │       │                    │
      ▼       ▼                    ▼
  Salvar   Exportar            ☁ Enviar
  (local)  XLS / PDF           (nuvem)
                                    │
                                    ▼
                    ┌───────────────────────────┐
                    │  Google Apps Script         │  Backend (gratuito)
                    │  Web App (doPost)           │
                    └──────────────┬──────────────┘
                                   │
                     ┌─────────────┼─────────────┐
                     ▼                           ▼
          ┌────────────────────┐      ┌────────────────────┐
          │  Google Sheets       │      │  E-mail de           │
          │  aba "Fichas"        │      │  confirmação          │
          │  (banco de dados)    │      │  (MailApp)            │
          └──────────┬───────────┘      └────────────────────┘
                     │
                     │  trigger diário (08h)
                     ▼
          ┌────────────────────────────┐
          │  verificarReconsultas()      │
          │  compara "Próxima Revisão"   │
          │  com hoje                    │
          └──────────────┬───────────────┘
                         │
                 faltam 30/15/3 dias?
                         │ sim
                         ▼
              ┌────────────────────┐
              │  E-mail de lembrete  │
              │  de reconsulta        │
              └────────────────────┘
```
