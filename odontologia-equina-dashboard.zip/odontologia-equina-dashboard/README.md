# Ficha Odontológica Equina — Arielle Costa

Dashboard web (front-end) + backend gratuito (Google Apps Script) para
preencher fichas odontológicas equinas, exportar XLS/PDF, salvar em uma
planilha central e notificar o proprietário por e-mail — incluindo lembrete
automático antes da data de reconsulta.

## Estrutura do projeto

```
odontologia-equina-dashboard/
├── README.md                      → este arquivo
├── index.html                     → o dashboard (front-end, hospedado no GitHub Pages)
├── apps-script/
│   ├── config.gs                  → configurações centrais (nomes de abas, e-mail, janelas de lembrete)
│   ├── Code.gs                    → recebe o envio do dashboard, grava na planilha, envia e-mail de confirmação
│   └── verificarReconsultas.gs    → trigger diário que verifica datas e envia lembretes
└── docs/
    └── fluxo.md                   → diagrama do fluxo completo
```

## Fluxo completo

```
[index.html no navegador]
   preenche ficha → "Salvar ficha" (guarda local, backup no navegador)
   preenche ficha → "⬇ XLS" / "⬇ PDF" (exporta na hora, sem servidor)
   preenche ficha → "☁ Enviar" ─────► [Google Apps Script Web App]
                                            │
                                            ├─► grava linha na [Google Sheets "Fichas"]
                                            └─► envia e-mail de confirmação ao proprietário

[Trigger diário no Apps Script, 08h]
   lê a planilha "Fichas" → calcula dias até "Próxima Revisão"
   se faltam 30, 15 ou 3 dias → envia e-mail de lembrete ao proprietário
   marca na planilha que aquele lembrete já foi enviado (evita duplicar)
```

Tudo isso usando apenas contas gratuitas: GitHub (hospedagem do site),
Google (planilha + automação + envio de e-mail via Gmail).

---

## Passo a passo de cadastro

### 1. Conta no GitHub (hospeda o dashboard)

1. Acesse **github.com** → **Sign up** → crie a conta com seu e-mail.
2. Clique em **New repository** (botão verde no canto superior direito).
3. Nome sugerido: `odontologia-equina-dashboard`. Marque **Public**. Clique **Create repository**.
4. Na página do repositório vazio, clique em **uploading an existing file** e arraste todos os arquivos desta pasta (`index.html`, `apps-script/`, `README.md`, `docs/`).
5. Clique **Commit changes**.
6. Vá em **Settings** → **Pages** (menu lateral) → em **Branch**, selecione `main` e pasta `/root` → **Save**.
7. Aguarde ~1 minuto. O GitHub mostrará o link do site, algo como:
   `https://seu-usuario.github.io/odontologia-equina-dashboard/`
   Esse é o link que você vai acessar (inclusive pelo celular) para preencher as fichas.

### 2. Conta Google (planilha + automação + e-mail)

Se você já tem Gmail, pule para o passo 3. Senão:
1. Acesse **accounts.google.com/signup** e crie a conta.

### 3. Criar a planilha "banco de dados"

1. Acesse **sheets.google.com** → **Planilha em branco**.
2. Renomeie para `Odontologia Equina - Base de Dados` (clique no título no topo).
3. Guarde essa planilha — é nela que toda ficha enviada vai virar uma linha.

### 4. Colar o código do backend (Apps Script)

1. Na planilha, vá em **Extensões → Apps Script**.
2. Isso abre o editor com um arquivo `Code.gs` vazio. Apague o conteúdo padrão.
3. Copie o conteúdo de **`apps-script/config.gs`** deste projeto → no editor, clique no `+` ao lado de "Arquivos" → **Script** → nomeie `config` → cole o conteúdo.
4. Repita para **`apps-script/Code.gs`** (arquivo `Code`) e **`apps-script/verificarReconsultas.gs`** (arquivo `verificarReconsultas`).
5. Clique no ícone de disquete (Salvar projeto).

### 5. Publicar como Web App (é isso que recebe os dados do dashboard)

1. No editor do Apps Script, clique em **Implantar → Nova implantação**.
2. Em **Tipo**, escolha **App da Web**.
3. Em **Quem pode acessar**, escolha **Qualquer pessoa** (necessário para o dashboard conseguir enviar dados sem login).
4. Clique **Implantar**. O Google vai pedir para você autorizar o script a acessar sua planilha e enviar e-mails em seu nome — clique **Continuar** e autorize (é a sua própria conta, é seguro).
5. Copie a **URL do app da Web** gerada (algo como `https://script.google.com/macros/s/AKfycb.../exec`).

### 6. Conectar o dashboard à planilha

1. No GitHub, abra o arquivo `index.html` do seu repositório → clique no ícone de lápis (editar).
2. Procure a linha:
   ```js
   const APPS_SCRIPT_URL = "";
   ```
3. Cole a URL copiada no passo 5, entre as aspas.
4. Clique **Commit changes**. Em ~1 minuto o site publicado já estará atualizado.

### 7. Ativar o lembrete automático de reconsulta

1. Volte ao editor do Apps Script (Extensões → Apps Script, na planilha).
2. No menu superior, selecione a função **`criarTriggerDiario`** na lista suspensa (ao lado do botão ▶ Executar).
3. Clique em **Executar** (▶). Autorize se solicitado.
4. Isso cria um gatilho que roda `verificarReconsultas` todo dia às 8h automaticamente — nunca mais precisa rodar manualmente.
5. Para conferir: **Gatilhos** (ícone de relógio no menu lateral esquerdo) → deve aparecer `verificarReconsultas · Baseado em tempo · Diariamente`.

### 8. Testar

1. Abra o link do GitHub Pages no celular ou computador.
2. Preencha uma ficha de teste com um e-mail seu no campo "E-mail".
3. Clique **☁ Enviar para a planilha + notificar proprietário**.
4. Confira: (a) uma linha nova na planilha "Fichas"; (b) um e-mail de confirmação na caixa de entrada.
5. Para testar o lembrete sem esperar dias, preencha "Próxima revisão" com uma data 3 dias à frente de hoje, envie a ficha, depois vá no Apps Script e rode `verificarReconsultas` manualmente (▶) — o e-mail de lembrete deve chegar na hora.

---

## Observações importantes

- **Limite gratuito de e-mail:** contas Gmail comuns permitem ~100 e-mails/dia via `MailApp` — mais que suficiente para uma clínica individual.
- **Dados sensíveis:** a planilha do Google é o único lugar onde os dados dos clientes ficam armazenados de fato. O repositório no GitHub deve conter apenas o código do site (nunca dados de pacientes).
- **Editar sem GitHub direto pelo navegador:** para projetos que crescerem, vale usar o editor `clasp` do Google (permite editar os `.gs` localmente e sincronizar com o GitHub via linha de comando) — posso te ajudar a configurar isso quando for necessário.
- **Formato de data:** a "Próxima revisão" deve ser preenchida como `dd/mm/aaaa` (ex: `13/09/2026`) para o script de lembrete conseguir interpretar corretamente.
