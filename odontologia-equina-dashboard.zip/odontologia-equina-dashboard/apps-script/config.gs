/**
 * config.gs
 * Configurações centrais do backend. Ajuste os valores abaixo depois de
 * criar a planilha (veja README.md).
 */

// Nome da aba dentro da planilha onde cada ficha vira uma linha.
const SHEET_FICHAS = 'Fichas';

// Nome/e-mail que aparece como remetente (usa a conta Gmail autorizada).
const REMETENTE_NOME = 'Arielle Costa · Odontologia Equina';

// Dias de antecedência em que o proprietário deve ser lembrado da reconsulta.
// Pode ter quantos valores quiser, ex: [30, 15, 3, 1]
const JANELAS_LEMBRETE_DIAS = [30, 15, 3];

// Cabeçalhos da planilha "Fichas" (nesta ordem). Se você mudar aqui,
// mude também a ordem correspondente em onFormSubmit_ e verificarReconsultas.
const CABECALHOS = [
  'Carimbo', 'Data', 'Equino', 'Raça', 'Idade', 'Sexo', 'Peso', 'ECC',
  'MV Clínico', 'Proprietário', 'E-mail', 'Fone', 'Local',
  'Histórico', 'Último Procedimento', 'Dentes Marcados', 'Achados Clínicos',
  'Procedimentos', 'Medicamentos', 'Honorários', 'Recomendações',
  'Próxima Revisão', 'Lembretes Enviados'
];
