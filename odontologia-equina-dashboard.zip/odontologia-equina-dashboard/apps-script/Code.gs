/**
 * Code.gs
 * Ponto de entrada da Web App. Recebe o POST enviado pelo botão
 * "Enviar para a planilha + notificar proprietário" do index.html,
 * grava a linha na aba "Fichas" e dispara o e-mail de confirmação.
 */
function doPost(e){
  try{
    const dados = JSON.parse(e.postData.contents);
    salvarFicha_(dados);
    if(dados.email){
      enviarEmailConfirmacao_(dados);
    }
    return ContentService.createTextOutput(JSON.stringify({ok:true}))
      .setMimeType(ContentService.MimeType.JSON);
  }catch(err){
    return ContentService.createTextOutput(JSON.stringify({ok:false, erro:String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function getSheet_(){
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_FICHAS);
  if(!sheet){
    sheet = ss.insertSheet(SHEET_FICHAS);
    sheet.appendRow(CABECALHOS);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function salvarFicha_(d){
  const sheet = getSheet_();
  sheet.appendRow([
    new Date(),
    d.data || '', d.equino || '', d.raca || '', d.idade || '', d.sexo || '',
    d.peso || '', d.ecc || '', d.mv || '', d.proprietario || '', d.email || '',
    d.fone || '', d.local || '', d.historico || '', d.ultimoProcedimento || '',
    d.dentesMarcados || '', d.achadosClinicos || '', d.procedimentos || '',
    d.medicamentos || '', d.honorarios || '', d.recomendacoes || '',
    d.proximaRevisao || '', '' // Lembretes Enviados começa vazio
  ]);
}

function enviarEmailConfirmacao_(d){
  const assunto = `Ficha odontológica registrada — ${d.equino || 'seu animal'}`;
  const corpo =
`Olá ${d.proprietario || ''},

A ficha odontológica do(a) ${d.equino || ''} foi registrada em ${d.data || ''}.

Procedimentos realizados: ${d.procedimentos || '—'}
Recomendações: ${d.recomendacoes || '—'}
Próxima revisão prevista: ${d.proximaRevisao || 'a definir'}

Qualquer dúvida, estamos à disposição.

${REMETENTE_NOME}`;

  MailApp.sendEmail(d.email, assunto, corpo);
}
