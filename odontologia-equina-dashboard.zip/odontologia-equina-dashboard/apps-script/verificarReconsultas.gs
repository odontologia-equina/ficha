/**
 * verificarReconsultas.gs
 * Roda 1x por dia (trigger diário configurado no editor do Apps Script,
 * veja README.md → "Criar o trigger diário"). Varre a planilha, calcula
 * quantos dias faltam para a "Próxima Revisão" de cada ficha e envia
 * lembrete por e-mail nas janelas definidas em JANELAS_LEMBRETE_DIAS.
 */
function verificarReconsultas(){
  const sheet = getSheet_();
  const dados = sheet.getDataRange().getValues();
  const header = dados[0];

  const col = {};
  header.forEach((nome, i) => col[nome] = i);

  const hoje = new Date();
  hoje.setHours(0,0,0,0);

  for(let linha = 1; linha < dados.length; linha++){
    const row = dados[linha];
    const dataRevisaoStr = row[col['Próxima Revisão']];
    const email = row[col['E-mail']];
    if(!dataRevisaoStr || !email) continue;

    const dataRevisao = parseDataBR_(dataRevisaoStr);
    if(!dataRevisao) continue;

    const diffDias = Math.round((dataRevisao - hoje) / (1000*60*60*24));
    if(diffDias < 0) continue; // já passou, não notifica mais

    if(JANELAS_LEMBRETE_DIAS.includes(diffDias)){
      const jaEnviados = String(row[col['Lembretes Enviados']] || '');
      const marcador = `D-${diffDias}`;
      if(jaEnviados.includes(marcador)) continue; // evita duplicar

      enviarLembreteReconsulta_({
        equino: row[col['Equino']],
        proprietario: row[col['Proprietário']],
        email: email,
        proximaRevisao: dataRevisaoStr,
        diffDias: diffDias
      });

      const novoValor = jaEnviados ? `${jaEnviados},${marcador}` : marcador;
      sheet.getRange(linha+1, col['Lembretes Enviados']+1).setValue(novoValor);
    }
  }
}

function parseDataBR_(str){
  // aceita dd/mm/aaaa ou dd/mm/aa
  const m = String(str).trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
  if(!m) return null;
  let [, d, mo, y] = m;
  if(y.length === 2) y = '20'+y;
  const dt = new Date(Number(y), Number(mo)-1, Number(d));
  dt.setHours(0,0,0,0);
  return dt;
}

function enviarLembreteReconsulta_(info){
  const assunto = `Lembrete: reconsulta odontológica de ${info.equino} em ${info.proximaRevisao}`;
  const corpo =
`Olá ${info.proprietario || ''},

Este é um lembrete de que a reconsulta odontológica do(a) ${info.equino} está marcada para ${info.proximaRevisao} (faltam ${info.diffDias} dia(s)).

Por favor, entre em contato para confirmar o agendamento.

${REMETENTE_NOME}`;

  MailApp.sendEmail(info.email, assunto, corpo);
}

/**
 * Execute esta função UMA VEZ manualmente no editor do Apps Script
 * para criar o trigger diário automático (veja README.md).
 */
function criarTriggerDiario(){
  // remove triggers antigos da mesma função, para não duplicar
  ScriptApp.getProjectTriggers().forEach(t=>{
    if(t.getHandlerFunction() === 'verificarReconsultas') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('verificarReconsultas')
    .timeBased()
    .everyDays(1)
    .atHour(8)
    .create();
}
